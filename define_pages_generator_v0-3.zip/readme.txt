Define Pages Generator Version v0.3
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Author:  Brian Tyler
Contact: btyler@math.ucl.ac.uk
Purpose: DefinePagesGenerator for Windows XP takes the hassle out of creating 
         new define pages, by generating the core files neccesary for a define
         page to function and putting them in the correct ZenCart directory
         structure. This application is based on the About Us mod, which gives
         an example of how to create a new define page.
         
Note:    This application was written in VB.NET. I don't think that it needs
         the Visual Basic runtimes, but it defintely needs the .NET 2.0
         framework to be installed on your computer. This is a free Windows
         Update, however it is optional so you may not have it installed.
         
         If you get the error message:
         
         "The application failed to initialize properly (0xc0000135).
         Click on OK to terminate the application."
         
         Or a message saying that you don't have the .NET 2.x framework
         installed, then that means you dont have the .NET 2.x framework
         installed. To install it goto
         
         http://www.microsoft.com/downloads/details.aspx?familyid=0856eacb-4362-4b0d-8edd-aab15c5e04f5&displaylang=en
         
         Instructions on how to use the application are contained in the 
         application itself.
         
         Any other problems please email me.
         
         
         

Disclaimer:
I have done my best to ensure that this application is free of bugs and that
it will not harm your computer, but you use it entirely at your own risk. It
comes without any guarantee of usability or suitability for purpose.

You are free to use and distribute this application as you wish.

